-- Akun aplikasi hanya mengelola data pada database praktikum.
REVOKE ALL PRIVILEGES ON tkj3_practice.* FROM 'tkj_practice'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON tkj3_practice.* TO 'tkj_practice'@'%';
